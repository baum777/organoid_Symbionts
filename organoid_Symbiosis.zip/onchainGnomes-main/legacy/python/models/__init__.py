"""Data models and dataclasses."""
