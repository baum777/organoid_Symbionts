"""Command presets."""
