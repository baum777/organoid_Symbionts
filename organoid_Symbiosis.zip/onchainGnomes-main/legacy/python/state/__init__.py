"""State management and persistence."""
